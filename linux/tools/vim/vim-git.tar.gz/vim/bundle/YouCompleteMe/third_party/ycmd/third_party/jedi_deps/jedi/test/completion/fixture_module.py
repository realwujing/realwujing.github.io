# Exists only for completion/pytest.py
import pytest

@pytest.fixture
def my_module_fixture():
    return 1.0
