from pytest import fixture


@fixture()
def admin_user():
    pass
