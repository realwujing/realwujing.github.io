void f(int a, int b);
int main() { f(5, 2); }
