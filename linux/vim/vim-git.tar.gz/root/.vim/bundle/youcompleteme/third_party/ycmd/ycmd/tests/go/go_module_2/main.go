package main

func f() {}

func main() {
  f()
}
