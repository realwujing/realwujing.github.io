using System;

namespace testy
{
	public class ContinuousTest
	{
		public static void Main (string[] args)
		{
			var test = String
			Main(
		}
		public static void Overloaded (int i, int a){}
		public static void Overloaded (string s){}
		public static void MultiArg (int i, string s){}
		public static void SigTest()
		{
			MultiArg(42,
			Overloaded( 123,
			if(
		}
	}
}
