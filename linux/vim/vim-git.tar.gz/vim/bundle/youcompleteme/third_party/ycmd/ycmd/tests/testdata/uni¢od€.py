def SomeMethod():
  return True
