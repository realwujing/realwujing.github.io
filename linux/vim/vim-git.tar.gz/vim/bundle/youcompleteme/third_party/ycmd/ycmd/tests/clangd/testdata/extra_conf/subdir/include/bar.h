struct Structure {
#ifdef BAR
    int member_bar;
#endif
};
