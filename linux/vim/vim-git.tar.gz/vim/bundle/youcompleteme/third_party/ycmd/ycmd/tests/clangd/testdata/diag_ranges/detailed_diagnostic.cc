int main() {
	int i;
        for (int j; j;i){}
}
