def Settings( **kwargs ):
  return {}
