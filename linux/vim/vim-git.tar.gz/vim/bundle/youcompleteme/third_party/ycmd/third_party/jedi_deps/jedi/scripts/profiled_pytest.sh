python3 -m profile -s tottime $(which pytest) $@
