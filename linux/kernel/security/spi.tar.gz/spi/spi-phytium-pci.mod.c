#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xd74c4fa0, "module_layout" },
	{ 0x399b02a, "pci_unregister_driver" },
	{ 0x374c2f2b, "__pci_register_driver" },
	{ 0xd4a37561, "_dev_err" },
	{ 0x980d04dd, "phytium_spi_add_host" },
	{ 0xd135307f, "pcim_iomap_table" },
	{ 0x7c9d78fd, "pcim_iomap_regions" },
	{ 0xbad8dfab, "pcim_enable_device" },
	{ 0x67feeca5, "devm_kmalloc" },
	{ 0xb2895bf6, "phytium_spi_remove_host" },
	{ 0xa2692da, "phytium_spi_suspend_host" },
	{ 0x6ad75aa8, "phytium_spi_resume_host" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=spi-phytium";

