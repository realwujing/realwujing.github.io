#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xd74c4fa0, "module_layout" },
	{ 0xca7e51e8, "platform_driver_unregister" },
	{ 0x39d27f26, "__platform_driver_register" },
	{ 0x430b364e, "devm_gpiod_get_index_optional" },
	{ 0x7615ba00, "gpiod_count" },
	{ 0x980d04dd, "phytium_spi_add_host" },
	{ 0x9768f9f1, "is_acpi_device_node" },
	{ 0x190a3f8d, "of_get_named_gpio_flags" },
	{ 0xc2c328d6, "devm_gpio_request" },
	{ 0x38b7fc18, "device_property_read_u32_array" },
	{ 0x556e4390, "clk_get_rate" },
	{ 0x815588a6, "clk_enable" },
	{ 0x7c9a7371, "clk_prepare" },
	{ 0x494954ce, "devm_clk_get" },
	{ 0x8c450b4a, "platform_get_irq" },
	{ 0xd7e07a69, "devm_ioremap_resource" },
	{ 0x664cb6f1, "platform_get_resource" },
	{ 0x67feeca5, "devm_kmalloc" },
	{ 0xd4a37561, "_dev_err" },
	{ 0xb077e70a, "clk_unprepare" },
	{ 0xb6e6d99d, "clk_disable" },
	{ 0xb2895bf6, "phytium_spi_remove_host" },
	{ 0xa2692da, "phytium_spi_suspend_host" },
	{ 0x6ad75aa8, "phytium_spi_resume_host" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=spi-phytium";

MODULE_ALIAS("acpi*:PHTY000E:*");
MODULE_ALIAS("acpi*:PHYT000E:*");
MODULE_ALIAS("of:N*T*Cphytium,spi");
MODULE_ALIAS("of:N*T*Cphytium,spiC*");
