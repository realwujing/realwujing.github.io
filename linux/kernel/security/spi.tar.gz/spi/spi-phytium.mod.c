#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xd74c4fa0, "module_layout" },
	{ 0x122d0950, "kmalloc_caches" },
	{ 0x179b4b73, "gpio_to_desc" },
	{ 0xdec821ab, "devm_spi_register_controller" },
	{ 0xed5294d4, "__spi_alloc_controller" },
	{ 0x14e90b0c, "gpiod_direction_output_raw" },
	{ 0x2072ee9b, "request_threaded_irq" },
	{ 0xd4a37561, "_dev_err" },
	{ 0xf6d7e04f, "put_device" },
	{ 0x6204b74, "kmem_cache_alloc_trace" },
	{ 0x7a49e750, "__dynamic_dev_dbg" },
	{ 0xc443b44f, "spi_finalize_current_transfer" },
	{ 0x37a0cba, "kfree" },
	{ 0x28318305, "snprintf" },
	{ 0x35fa3c19, "spi_controller_suspend" },
	{ 0x5b6ac8c8, "spi_controller_resume" },
	{ 0xc1514a3b, "free_irq" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

