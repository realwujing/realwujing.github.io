#include "job2.h"

#include <QProcess>

Job2::Job2(QObject *parent)
    : QThread(parent),
      State(0),
      processId(-1)
{
}

Job2::~Job2()
{
    qInfo() << "~Thread";
    stop();
}

Job2::State Job2::state() const
{
    return state;
}

void Job2::start(Priority pri)
{
    QThread::start(pri);
    state = RUNNING;
}

int Job2::stop()
{
    if (QThread::isRunning())
    {
        QProcess process;
        process.start("kill", {"-9", processId});
        if (QProcess::NormalExit != process.exitCode)
        {
            qCritical() << "kill -9 pid:" << processId << "failed";
            QThread::terminate();
            return -1;
        }
        state = STOPED;
        return 0;
    }
    return -1;
}

int Job2::pause()
{
    if (QThread::isRunning())
    {
        QProcess process;
        process.start("kill", {"-STOP", processId});
        if (QProcess::NormalExit != process.exitCode)
        {
            qCritical() << "kill -STOP pid:" << processId << "failed";
            return -1;
        }
        state = PAUSED;
        return 0;
    }
    return -1;
}

int Job2::resume()
{
    if (QThread::isRunning())
    {
        QProcess process;
        process.start("kill", {"-CONT", processId});
        if (QProcess::NormalExit != process.exitCode)
        {
            qCritical() << "kill -CONT pid:" << processId << "failed";
            return -1;
        }
        state = RUNNING;
        return 0;
    }
    return -1;
}

void Job2::run()
{
    qInfo() << "enter thread : " << QThread::currentThreadId();

    process(func);

    qInfo() << "exit thread : " << QThread::currentThreadId();
}

void Job2::process(std::function<int()> func)
{
    processId = func();
}
